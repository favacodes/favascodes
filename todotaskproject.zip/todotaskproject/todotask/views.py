from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect, render, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import DeleteView, UpdateView, DetailView, ListView
from django.views.generic.edit import FormMixin

from todotask.forms import TodoForm
from todotask.models import Task


class Tasklistview(FormMixin, ListView):
    model = Task
    template_name = 'home.html'
    context_object_name = 'task1'
    form_class = TodoForm
    success_url = reverse_lazy('cbvhome')  # Replace 'cbvhome' with your actual URL name

    def get_queryset(self):
        if self.request.user.is_superuser:
            return Task.objects.all()
        return Task.objects.filter(user=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = self.get_form()
        return context

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()
            return redirect(self.get_success_url())
        else:
            return self.form_invalid(form)




class TaskDetailview(DetailView):
    model=Task
    template_name = 'detail.html'
    context_object_name = 'task'

    def test_func(self):
        task = self.get_object()
        return self.request.user == task.user or self.request.user.is_superuser

class TaskUpdateView(UpdateView):
    model= Task
    template_name = 'update.html'
    context_object_name = 'task'
    fields = ('name','date')

    def get_success_url(self):
         return reverse_lazy('cbvdetail',kwargs={'pk':self.object.id})
class TaskDeleteView(DeleteView):
    model= Task
    template_name = 'delete.html'
    success_url = reverse_lazy('cbvhome')






def add(request):
    task1 = Task.objects.all()
    if request.method == 'POST':
        name = request.POST.get('task', "")
        status = request.POST.get('status', '')
        description = request.POST.get('description', "")
        date = request.POST.get('date', '')
        completion_report = request.POST.get('completion_report', '')
        worked_hours=request.POST.get('worked_hours', '')

        task = Task(
            name=name,
            date=date,
            description=description,
            status=status,
            completion_report=completion_report,
            user=request.user
            # Assign the logged-in user
        )
        if status == 'Completed':
            task.completion_report = completion_report
            task.worked_hours = worked_hours
        task.save()
        return redirect('/')  # Replace 'index' with your desired redirect
    return render(request, 'home.html', {'task1': task1})
def delete(request,taskid):
    task=Task.objects.get(id=taskid)
    if request.method =='POST':
        task.delete()
        return redirect('/')
    return render(request,'delete.html')
def update(request, id):
    task = get_object_or_404(Task, id=id)

    # Check if the current user is the task owner or a superuser
    if request.user != task.user and not request.user.is_superuser:
        raise PermissionDenied("You do not have permission to edit this task.")

    form = TodoForm(request.POST or None, instance=task)
    if form.is_valid():
        form.save()
        return redirect("/")
    return render(request, 'edit.html', {'f': form, 'task': task})